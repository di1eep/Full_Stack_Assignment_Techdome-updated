import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

function LandingPage() {
  const [displayText, setDisplayText] = useState(false);

  const handleClick = () => {
    setDisplayText(true);
  };

  return (
    <div>
      <ul className="nav nav-tabs">
        <li className="nav-item">
          <Link className="nav-link active" aria-current="page" to="/">LOAN APP</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/Customer/login">Customer LOGIN</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/Admin/login">Admin Login</Link>
        </li>
        <li className="nav-item">
          <span className="nav-link" onClick={handleClick} aria-disabled="true">ABOUT LOAN APP</span>
          {displayText && <p>this is a loan app that providing loan from past few years because its a loan app</p>}
        </li>
      </ul>
    </div>
  );
}

export default LandingPage;
