import React, { useState } from 'react';
import { Link } from 'react-router-dom';
// SignupForm component
const SignupForm = ({ handleSignup }) => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    // Pass the signup data to the parent component for handling
    handleSignup({ username, email, password });
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Username:
        <input
          type="text"
          value={username}
          onChange={(event) => setUsername(event.target.value)}
          required
        />
      </label>
      <label>
        Email:
        <input
          type="email"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          required
        />
      </label>
      <label>
        Password:
        <input
          type="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          required
        />
      </label>
      <button type="submit">Sign Up</button>
    </form>
  );
};

// App component
const Signup = () => {
  const handleSignup = (userData) => {
    // Dummy signup logic for demonstration
    console.log('User Signed Up:', userData);
    // You can add further logic here, such as sending the signup data to a server
  };

  return (
    <div>
      <h1>Signup Page</h1>
      <SignupForm handleSignup={handleSignup} />
      <Link to="/Admin/login">
      <p>Already an existing user</p>
     <button type="button">
          Sign Up
     </button>
     </Link>
    </div>
  );
};

export default SignupForm;
