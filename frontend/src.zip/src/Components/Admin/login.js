import React, { useState } from 'react';
import { Link } from 'react-router-dom';

// LoginForm component
const LoginForm = ({ handleLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    // Pass the username and password to the parent component for handling
    handleLogin(username, password);
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Username:
        <input
          type="text"
          value={username}
          onChange={(event) => setUsername(event.target.value)}
          required
        />
      </label>
      <label>
        Password:
        <input
          type="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          required
        />
      </label>
      <button type="submit">Login</button>
    </form>
  );
};

// App component
const Login = () => {
  const handleLogin = (username, password) => {
    // Dummy login logic for demonstration
    if (username === 'admin' && password === 'password') {
      alert('Login successful!');
    } else {
      alert('Invalid username or password');
    }
  };

  return (
    <div>
      <h1>Admin Login Page</h1>
      <LoginForm handleLogin={handleLogin} />
      <Link to="/Admin/signup">
      <p>New User ?</p>
     <button type="button">
          Sign Up
     </button>
     </Link>
    </div>
  );
};

export default LoginForm;

