import React,{useState} from 'react'
import Table from "react-bootstrap/Table";

function LoanList() {
  const [loans, setLoans] = useState([
    {
      id: "1",
      requestDate: "20/04/24",
      amount: "10000",
      tenure: 6,
      approval_status: "Approved",
      tenure_status: "2/6",
      loan_status: "Pending",
    },
    {
      id: "2",
      requestDate: "22/04/24",
      amount: "20000",
      tenure: 4,
      approval_status: "Pending",
      tenure_status: "0/4",
      loan_status: "Pending",
    },
  ]);

  

  return (
    <Table striped bordered hover>
      <thead>
        <tr>
          <th>Id</th>
          <th>Loan Request Date</th>
          <th>Amount</th>
          <th>Tenure</th>
          <th>Approval Status</th>
          <th>Tenure Status</th>
          <th>Loan Payment Status</th>
        </tr>
      </thead>
      <tbody>{loans.length > 0 &&
        loans.map((loan)=>{
          return (
            <tr key={loan.id}>
              <td>{loan.id}</td>
              <td>{loan.requestDate}</td>
              <td>{loan.amount}</td>
              <td>{loan.tenure}</td>
              <td>{loan.approval_status}</td>
              <td>{loan.tenure_status}</td>
              <td>{loan.loan_status}</td>
            </tr>
          );
        })
      }</tbody>
    </Table>
  );
}

export default LoanList