import React,{useState} from "react"
import Table from "react-bootstrap/Table";

function CreateLoan() {
  const [loans, setLoans] = useState([ 
    {
      id: "1",
      amount: "10000",
      tenure: 6,
      currentDate: "20/04/24",
    },
    {
      id: "2",
      amount: "15000",
      tenure: 5,
      currentDate: "20/04/24",
    },
  ]);


  return (
      
     <div>

    <Table striped bordered hover>
      <thead>
        <tr>
          <th>Id</th>
          <th>Amount</th>
          <th>Tenure</th>
          <th>Loan Creation Date</th>
        </tr>
      </thead>
      <tbody>{loans.length > 0 &&
        loans.map((loan)=>{ // Fixed variable name from CreateLoan to loan for mapping
          return (
            <tr key={loan.id}> 
              <td>{loan.id}</td> 
              <td>{loan.amount}</td>
              <td>{loan.tenure}</td>
              <td>{loan.currentDate}</td>
            </tr>
          );
        })
      }</tbody>
    </Table>

    <button>Apply for a loan</button>

    </div>

  );
}

export default CreateLoan;