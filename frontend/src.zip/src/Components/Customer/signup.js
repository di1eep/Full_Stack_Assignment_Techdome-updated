import React, { useState } from 'react';
import { Link } from 'react-router-dom';

// SignupForm component
const SignupForm = ({ handleSignup }) => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await fetch('http://localhost:5000/auth/signup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, email, password }),
      });
      const data = await response.json();
      if (response.ok) {
        // Signup successful, perform further actions here
        handleSignup(data);
      } else {
        setError(data.message);
      }
    } catch (error) {
      console.error('Error during signup:', error);
      setError('Failed to signup. Please try again later.');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      {error && <div>{error}</div>}
      <label>
        Username:
        <input
          type="text"
          value={username}
          onChange={(event) => setUsername(event.target.value)}
          required
        />
      </label>
      <label>
        Email:
        <input
          type="email"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          required
        />
      </label>
      <label>
        Password:
        <input
          type="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          required
        />
      </label>
      <button type="submit">Sign Up</button>
    </form>
  );
};

// App component
const Signup = () => {
  const handleSignup = (userData) => {
    // Dummy signup logic for demonstration
    console.log('User Signed Up:', userData);
    // You can add further logic here, such as redirecting to a different page
  };

  return (
    <div>
      <h1>Signup Page</h1>
      <SignupForm handleSignup={handleSignup} />
      <Link to="/Customer/login">
        <p>Already an existing user ?</p>
        <button type="button">Login</button>
      </Link>
    </div>
  );
};

export default Signup;
