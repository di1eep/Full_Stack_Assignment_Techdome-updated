import React from 'react';

function LoanRepaymentPage() {
  // Sample loan repayment page UI
  return (
    <div>
      <h2>Loan Repayment Page</h2>
      <p>Loan amount: $10,000</p>
      <p>Number of terms: 6</p>
      <p>Terms with status:</p>
      {/* Add terms with status */}
      <button>Pay Current Pending Term</button>
      <button>Pay Custom Amount</button>
    </div>
  );
}

export default LoanRepaymentPage;
