import React, { useState } from 'react';
import { Link } from 'react-router-dom'; 




function Dashboard() {
    const [displayText, setDisplayText] = useState(false);
  
    const handleClick = () => {
      setDisplayText(true);
    };
  return (
    <div>
      <ul className="nav nav-tabs">
        <li className="nav-item">
          <Link className="nav-link" to="/Customer/LoanList">Customer LOGIN LIST</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/Customer/CreateLoan">Apply for a new Loan</Link>
        </li>
        <li className="nav-item">
          <Link className="nav-link" to="/Customer/LoanRepaymentPage">Customer Loan repayment page</Link>
        </li>
        <li className="nav-item">
          <span className="nav-link" onClick={handleClick} tabIndex="0">ABOUT LOAN APP</span>
          {displayText && <p>this is a loan app that providing loan from past few years because its a loan app</p>}
        </li>
      </ul>
    </div>
  );
}

export default Dashboard;