import React from "react";
import { Routes, Route } from "react-router-dom";
import LandingPage from "./Components/UIElements/landingPage";
import CLogin from "./Components/Customer/login";
import CSignup from "./Components/Customer/signup";
import LoginForm from "./Components/Admin/login";
import SignupForm from "./Components/Admin/signup";

import Dashboard from "./Components/Customer/Dashboard";
import LoanList from "./Components/Customer/LoanList";
import CreateLoan from "./Components/Customer/CreateLoan";
import LoanRepaymentPage from "./Components/Customer/LoanRepayment";

import "./App.css";

function App() {
  return (
    <div>
      <LandingPage />

      <Routes>
        <Route exact path="/" component={LandingPage} />
        <Route path="/Customer/Login" component={CLogin} />
        <Route path="/Customer/Signup" component={CSignup} />
        <Route path="/Customer/Dashboard" component={Dashboard} />
        <Route path="/Customer/LoanList" component={LoanList} />
        <Route path="/Customer/CreateLoan" component={CreateLoan} />
        <Route
          path="/Customer/LoanRepaymentPage"
          component={LoanRepaymentPage}
        />
        <Route path="/Admin/Login" component={LoginForm} />
        <Route path="/Admin/Signup" component={SignupForm} />
      </Routes>
    </div>
  );
}

export default App;
